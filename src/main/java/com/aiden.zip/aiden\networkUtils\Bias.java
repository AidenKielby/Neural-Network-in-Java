package com.aiden.networkUtils;

public class Bias {
    private double bias = 0;
    private int neuronIndex;

    public Bias(double bias, int neuronIndex) {
        this.bias = bias;
        this.neuronIndex = neuronIndex;
    }

    public double getBias() {
        return bias;
    }

    public void setBias(double bias) {
        this.bias = bias;
    }

    public int getNeuronIndex() {
        return neuronIndex;
    }

    public void setNeuronIndex(int neuronIndex) {
        this.neuronIndex = neuronIndex;
    }
}
