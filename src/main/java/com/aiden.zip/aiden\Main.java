package com.aiden;

import com.aiden.networkUtils.NTrainer;
import com.aiden.networkUtils.Network;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Network network = new Network(2, 5, 4, 2);



        ArrayList<ArrayList<Double>> inputs = new ArrayList<>();

// Points (x, y) for the graph
        ArrayList<Double> point1 = new ArrayList<>();
        point1.add(2.0);
        point1.add(3.0);
        inputs.add(point1);
        ArrayList<Double> point2 = new ArrayList<>();
        point2.add(5.0);
        point2.add(7.0);
        inputs.add(point2);
        ArrayList<Double> point3 = new ArrayList<>();
        point3.add(8.0);
        point3.add(2.0);
        inputs.add(point3);
        ArrayList<Double> point4 = new ArrayList<>();
        point4.add(1.0);
        point4.add(9.0);
        inputs.add(point4);
        ArrayList<Double> point5 = new ArrayList<>();
        point5.add(4.0);
        point5.add(6.0);
        inputs.add(point5);
        ArrayList<Double> point6 = new ArrayList<>();
        point6.add(7.0);
        point6.add(1.0);
        inputs.add(point6);
        ArrayList<Double> point7 = new ArrayList<>();
        point7.add(3.0);
        point7.add(4.0);
        inputs.add(point7);
        ArrayList<Double> point8 = new ArrayList<>();
        point8.add(6.0);
        point8.add(5.0);
        inputs.add(point8);
        ArrayList<Double> point9 = new ArrayList<>();
        point9.add(9.0);
        point9.add(3.0);
        inputs.add(point9);
        ArrayList<Double> point10 = new ArrayList<>();
        point10.add(10.0);
        point10.add(8.0);
        inputs.add(point10);
        ArrayList<Double> point11 = new ArrayList<>();
        point11.add(1.0);
        point11.add(5.0);
        inputs.add(point11);
        ArrayList<Double> point12 = new ArrayList<>();
        point12.add(11.0);
        point12.add(6.0);
        inputs.add(point12);
        ArrayList<Double> point13 = new ArrayList<>();
        point13.add(12.0);
        point13.add(15.0);
        inputs.add(point13);
        ArrayList<Double> point14 = new ArrayList<>();
        point14.add(3.0);
        point14.add(2.0);
        inputs.add(point14);
        ArrayList<Double> point15 = new ArrayList<>();
        point15.add(6.0);
        point15.add(9.0);
        inputs.add(point15);
        ArrayList<Double> point16 = new ArrayList<>();
        point16.add(14.0);
        point16.add(11.0);
        inputs.add(point16);
        ArrayList<Double> point17 = new ArrayList<>();
        point17.add(2.0);
        point17.add(1.0);
        inputs.add(point17);
        ArrayList<Double> point18 = new ArrayList<>();
        point18.add(9.0);
        point18.add(12.0);
        inputs.add(point18);
        ArrayList<Double> point19 = new ArrayList<>();
        point19.add(7.0);
        point19.add(5.0);
        inputs.add(point19);
        ArrayList<Double> point20 = new ArrayList<>();
        point20.add(4.0);
        point20.add(8.0);
        inputs.add(point20);
        ArrayList<Double> point21 = new ArrayList<>();
        point21.add(10.0);
        point21.add(15.0);
        inputs.add(point21);
        ArrayList<Double> point22 = new ArrayList<>();
        point22.add(13.0);
        point22.add(9.0);
        inputs.add(point22);
        ArrayList<Double> point23 = new ArrayList<>();
        point23.add(8.0);
        point23.add(10.0);
        inputs.add(point23);
        ArrayList<Double> point24 = new ArrayList<>();
        point24.add(1.0);
        point24.add(3.0);
        inputs.add(point24);
        ArrayList<Double> point25 = new ArrayList<>();
        point25.add(5.0);
        point25.add(2.0);
        inputs.add(point25);
        ArrayList<Double> point26 = new ArrayList<>();
        point26.add(11.0);
        point26.add(13.0);
        inputs.add(point26);
        ArrayList<Double> point27 = new ArrayList<>();
        point27.add(15.0);
        point27.add(14.0);
        inputs.add(point27);
        ArrayList<Double> point28 = new ArrayList<>();
        point28.add(3.0);
        point28.add(6.0);
        inputs.add(point28);
        ArrayList<Double> point29 = new ArrayList<>();
        point29.add(6.0);
        point29.add(3.0);
        inputs.add(point29);
        ArrayList<Double> point30 = new ArrayList<>();
        point30.add(7.0);
        point30.add(7.0);
        inputs.add(point30);
        ArrayList<Double> point31 = new ArrayList<>();
        point31.add(4.0);
        point31.add(3.0);
        inputs.add(point31);
        ArrayList<Double> point32 = new ArrayList<>();
        point32.add(9.0);
        point32.add(8.0);
        inputs.add(point32);

// Corresponding targets (top=1, bottom=1)
        ArrayList<ArrayList<Double>> targets = new ArrayList<>();

// Targets indicating if the points are above or below
        ArrayList<Double> target1 = new ArrayList<>();
        target1.add(1.0);  // top
        target1.add(0.0);  // bottom
        targets.add(target1);

        ArrayList<Double> target2 = new ArrayList<>();
        target2.add(1.0);
        target2.add(0.0);
        targets.add(target2);

        ArrayList<Double> target3 = new ArrayList<>();
        target3.add(0.0);
        target3.add(1.0);  // bottom
        targets.add(target3);

        ArrayList<Double> target4 = new ArrayList<>();
        target4.add(1.0);  // top
        target4.add(0.0);
        targets.add(target4);

        ArrayList<Double> target5 = new ArrayList<>();
        target5.add(1.0);
        target5.add(0.0);
        targets.add(target5);

        ArrayList<Double> target6 = new ArrayList<>();
        target6.add(0.0);
        target6.add(1.0);  // bottom
        targets.add(target6);

        ArrayList<Double> target7 = new ArrayList<>();
        target7.add(1.0);  // top
        target7.add(0.0);
        targets.add(target7);

        ArrayList<Double> target8 = new ArrayList<>();
        target8.add(1.0);  // top
        target8.add(0.0);
        targets.add(target8);

        ArrayList<Double> target9 = new ArrayList<>();
        target9.add(1.0);  // top
        target9.add(0.0);
        targets.add(target9);

        ArrayList<Double> target10 = new ArrayList<>();
        target10.add(0.0);
        target10.add(1.0);  // bottom
        targets.add(target10);

        ArrayList<Double> target11 = new ArrayList<>();
        target11.add(1.0);  // top
        target11.add(0.0);
        targets.add(target11);

        ArrayList<Double> target12 = new ArrayList<>();
        target12.add(0.0);
        target12.add(1.0);  // bottom
        targets.add(target12);

        ArrayList<Double> target13 = new ArrayList<>();
        target13.add(1.0);
        target13.add(0.0);
        targets.add(target13);
        ArrayList<Double> target14 = new ArrayList<>();
        target14.add(0.0);
        target14.add(1.0);
        targets.add(target14);
        ArrayList<Double> target15 = new ArrayList<>();
        target15.add(1.0);
        target15.add(0.0);
        targets.add(target15);
        ArrayList<Double> target16 = new ArrayList<>();
        target16.add(1.0);
        target16.add(0.0);
        targets.add(target16);
        ArrayList<Double> target17 = new ArrayList<>();
        target17.add(0.0);
        target17.add(1.0);
        targets.add(target17);
        ArrayList<Double> target18 = new ArrayList<>();
        target18.add(1.0);
        target18.add(0.0);
        targets.add(target18);
        ArrayList<Double> target19 = new ArrayList<>();
        target19.add(0.0);
        target19.add(1.0);
        targets.add(target19);
        ArrayList<Double> target20 = new ArrayList<>();
        target20.add(1.0);
        target20.add(0.0);
        targets.add(target20);
        ArrayList<Double> target21 = new ArrayList<>();
        target21.add(1.0);
        target21.add(0.0);
        targets.add(target21);
        ArrayList<Double> target22 = new ArrayList<>();
        target22.add(0.0);
        target22.add(1.0);
        targets.add(target22);
        ArrayList<Double> target23 = new ArrayList<>();
        target23.add(1.0);
        target23.add(0.0);
        targets.add(target23);
        ArrayList<Double> target24 = new ArrayList<>();
        target24.add(1.0);
        target24.add(0.0);
        targets.add(target24);
        ArrayList<Double> target25 = new ArrayList<>();
        target25.add(0.0);
        target25.add(1.0);
        targets.add(target25);
        ArrayList<Double> target26 = new ArrayList<>();
        target26.add(1.0);
        target26.add(0.0);
        targets.add(target26);
        ArrayList<Double> target27 = new ArrayList<>();
        target27.add(1.0);
        target27.add(0.0);
        targets.add(target27);
        ArrayList<Double> target28 = new ArrayList<>();
        target28.add(1.0);
        target28.add(0.0);
        targets.add(target28);
        ArrayList<Double> target29 = new ArrayList<>();
        target29.add(0.0);
        target29.add(1.0);
        targets.add(target29);
        ArrayList<Double> target30 = new ArrayList<>();
        target30.add(1.0);
        target30.add(0.0);
        targets.add(target30);
        ArrayList<Double> target31 = new ArrayList<>();
        target31.add(0.0);
        target31.add(1.0);
        targets.add(target31);
        ArrayList<Double> target32 = new ArrayList<>();
        target32.add(1.0);
        target32.add(0.0);
        targets.add(target32);

        //network.addInputs(11);
        //network.addInputs(6);

        //network.forwardPass();
        //System.out.println(network.returnLargestOutputInFormOfIndex());
        //System.out.println(network.toList());

        //network.setTargets(new ArrayList<>(target12));
        //System.out.println(network.error());

        //System.out.println(" ");

        //network.clearTargets();
        //network.clearInputs();
        //network.clearNeuronValues();

        NTrainer networkTrainer = new NTrainer(network, targets, inputs, 200_000);
        Network network1 = networkTrainer.train();

        network1.addInputs(11);
        network1.addInputs(6);

        network1.forwardPass();
        System.out.println(network1.returnLargestOutputInFormOfIndex());
        System.out.println(network1.toList());

        network1.setTargets(new ArrayList<>(target12));
        System.out.println(network1.error());
        if(network1.returnLargestOutputInFormOfIndex() == 1){
            System.out.println("right");
        }else{
            System.out.println("wrong");
        }

        network1.clearInputs();


        network1.addInputs(2);
        network1.addInputs(3);
        network1.forwardPass();

        if(network1.returnLargestOutputInFormOfIndex() == 0){
            System.out.println("right");
        }else{
            System.out.println("wrong");
        }

        network1.clearInputs();


        network1.addInputs(9);
        network1.addInputs(8);
        network1.forwardPass();

        if(network1.returnLargestOutputInFormOfIndex() == 1){
            System.out.println("right");
        }else{
            System.out.println("wrong");
        }

        network1.clearInputs();


        network1.addInputs(13);
        network1.addInputs(14);
        network1.forwardPass();

        if(network1.returnLargestOutputInFormOfIndex() == 0){
            System.out.println("right");
        }else{
            System.out.println("wrong");
        }

    }
}